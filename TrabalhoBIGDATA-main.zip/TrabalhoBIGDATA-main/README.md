# TrabAppTopicos
Trabalho tópicos de big data em python
Professor ROBSON LORBIESKI
Faculdade : Estácio
